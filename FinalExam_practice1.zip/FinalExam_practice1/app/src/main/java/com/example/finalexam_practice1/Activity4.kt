package com.example.finalexam_practice1

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.finalexam_practice1.databinding.Activity4Binding

class Activity4 : AppCompatActivity() {
    lateinit var binding: Activity4Binding

    val brr = object:BroadcastReceiver(){
        override fun onReceive(p0: Context?, p1: Intent?) {
            var action = intent.action
            if(action == Intent.ACTION_BATTERY_CHANGED){
                var remain = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
                binding.btv.setText("($remain%)")
                binding.bpbar.progress = remain
            }
        }
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(brr)
    }

    override fun onResume() {
        super.onResume()
        var iff = IntentFilter()
        iff.addAction(Intent.ACTION_BATTERY_CHANGED)
        registerReceiver(brr,iff)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = Activity4Binding.inflate(layoutInflater)
        setContentView(binding.root)
        title = "포토샵"

        binding.btnBack3.setOnClickListener { finish() }

        binding.zi.setOnClickListener{
            MyView.sX += 0.2f
            MyView.sY += 0.2f
            binding.mv.invalidate()
        }

        binding.zo.setOnClickListener{
            MyView.sX -= 0.2f
            MyView.sY -= 0.2f
            binding.mv.invalidate()
        }

        binding.rot.setOnClickListener{
            MyView.angle += 0.2f
            binding.mv.invalidate()
        }

        binding.dk.setOnClickListener{
            MyView.color -= 0.2f
            binding.mv.invalidate()
        }

        binding.blr.setOnClickListener{
            MyView.blur = !MyView.blur
            binding.mv.invalidate()
        }
    }
}