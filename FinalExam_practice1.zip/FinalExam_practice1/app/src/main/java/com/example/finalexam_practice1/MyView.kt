package com.example.finalexam_practice1

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

class MyView(context: Context?, attrs: AttributeSet?) : View(context, attrs){

    companion object {
        var sX = 1f
        var sY = 1f
        var angle = 0f
        var color = 1f
        var blur = false
    }

    override fun onDraw(canvas: Canvas?){
        super.onDraw(canvas!!)
        var pic = BitmapFactory.decodeResource(resources, R.drawable.lena256)
        var paint = Paint()
        val cenX = canvas.width.toFloat() / 2
        val cenY = canvas.height.toFloat() / 2
        val picX = cenX - (pic.width / 2)
        val picY = cenY - (pic.height / 2)

        canvas.scale(sX,sY, cenX, cenY)
        canvas.rotate(angle, cenX, cenY)
        val arr = floatArrayOf(
            color, 0f, 0f, 0f, 0f,
            0f, color, 0f, 0f, 0f,
            0f, 0f, color, 0f, 0f,
            0f, 0f, 0f, 1f, 0f,
        )
        val cm = ColorMatrix(arr)
        paint.colorFilter = ColorMatrixColorFilter(cm)

        if(blur){
            var bMask = BlurMaskFilter(30f, BlurMaskFilter.Blur.NORMAL)
            paint.maskFilter = bMask
        }

        canvas.drawBitmap(pic,picX,picY,paint)
        pic.recycle()
    }
}