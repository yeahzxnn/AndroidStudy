package com.example.finalexam_practice1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.finalexam_practice1.databinding.Activity2Binding
import java.util.Calendar
import java.io.IOException
import java.nio.charset.Charset
import java.util.*

class Activity2 : AppCompatActivity() {

    val cal = Calendar.getInstance()
    var year = cal.get(Calendar.YEAR)
    var month = cal.get(Calendar.MONTH)
    var day = cal.get(Calendar.DAY_OF_MONTH)

    lateinit var binding: Activity2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var binding = Activity2Binding.inflate(layoutInflater)
        setContentView(binding.root)
        title = "일기장"

        binding.handle.setText("$year/${month + 1}/$day")

        val fname = "$year${month + 1}$day.txt"
        val str = read(fname)
        if (str == null) {
            binding.edt.setText("")
            binding.edt.hint = "일기 없음"
            binding.btn.text = "새로 저장"
        } else {
            binding.edt.setText(str)
            binding.btn.text = "수정하기"
        }

        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.dp.init(year, month, day) { _, y, m, d ->
            year = y;
            month = m+1;
            day = d;
            binding.handle.setText("$year/${month}/$day")
            val fname = "$year${month + 1}$day.txt"
            val str = read(fname)
            if (str == null) {
                binding.edt.setText("")
                binding.edt.hint = "일기 없음"
                binding.btn.text = "새로 저장"
            } else {
                binding.edt.setText(str)
                binding.btn.text = "수정하기"
            }

        }

        binding.btn.setOnClickListener {
            val fname = "$year${month + 1}$day.txt"
            var outFs = openFileOutput(fname, 0)
            outFs.write(binding.edt.text.toString().toByteArray())
            outFs.close()
            val str = read(fname)
            if (str == null) {
                binding.edt.setText("")
                binding.edt.hint = "일기 없음"
                binding.btn.text = "새로 저장"
            } else {
                binding.edt.setText(str)
                binding.btn.text = "수정하기"
            }

        }


    }

    fun read(fname: String?): String?{
        var str:String? = null
        try {
            var inFs = openFileInput(fname)
            var tmp = ByteArray(inFs.available())
            inFs.read(tmp)
            inFs.close()
            str = tmp.toString(Charsets.UTF_8).trim()
        } catch (e: IOException){

        }
        return str
    }

}

