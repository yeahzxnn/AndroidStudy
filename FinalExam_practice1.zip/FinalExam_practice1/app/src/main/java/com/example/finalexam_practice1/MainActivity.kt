package com.example.finalexam_practice1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import com.example.finalexam_practice1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        title = "기말고사"
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        super.onCreateOptionsMenu(menu!!)
        menu.add(0,1,0,"일기장")
        menu.add(0,2,0,"선수 기록 관리")
        menu.add(0,3,0,"포토샵")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        super.onOptionsItemSelected(item)
        when(item.itemId){
            1 -> {
                intent = Intent(applicationContext, Activity2::class.java)
                startActivity(intent)
            }
            2 -> {
                intent = Intent(applicationContext, Activity3::class.java)
                startActivity(intent)
            }
            3 -> {
                intent = Intent(applicationContext, Activity4::class.java)
                startActivity(intent)
            }
        }
        return true
    }
}