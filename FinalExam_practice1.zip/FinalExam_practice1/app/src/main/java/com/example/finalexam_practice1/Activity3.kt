package com.example.finalexam_practice1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock
import com.example.finalexam_practice1.databinding.Activity3Binding
import kotlin.random.Random

class Activity3 : AppCompatActivity() {
    lateinit var binding: Activity3Binding
    var pnum = 1
    var sList: ArrayList<String> = arrayListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = Activity3Binding.inflate(layoutInflater)
        setContentView(binding.root)
        title = "선수 기록 관리"


        binding.btnBack2.setOnClickListener {
            finish()
        }

        binding.btnstart.setOnClickListener {
            if(binding.pbar1.progress != 0){
                pnum += 2
                binding.pbar1.progress = 0
                binding.pbar2.progress = 0
            }
            object : Thread(){
                override fun run() {
                    var time: Long = 0
                    while (binding.pbar1.progress != 100 && binding.pbar2.progress != 100){
                        binding.pbar1.progress += 10
                        val interval = Random.nextInt(100).toLong()
                        SystemClock.sleep(interval)
                        time += interval
                        runOnUiThread { binding.tv1.setText("선수${pnum}($time")}
                    }
                }

            }.start()
            object : Thread(){
                override fun run(){
                    var time:Long = 0
                    while (binding.pbar1.progress != 100 && binding.pbar2.progress != 100){
                        binding.pbar2.progress += 10
                        val interval = Random.nextInt(100).toLong()
                        SystemClock.sleep(interval)
                        time += interval
                        runOnUiThread { binding.tv2.setText("선수${pnum+1}($time")}
                    }
                }


            }.start()
        }

    }
}